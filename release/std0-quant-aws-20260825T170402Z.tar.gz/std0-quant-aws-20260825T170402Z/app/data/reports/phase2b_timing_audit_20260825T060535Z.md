# Phase 2B-Research v3 Timing & Replication Audit

**RESEARCH ONLY - NO REAL TRADING**

MEASURE THE CLOCK BEFORE MEASURING THE LAG.

- Research spec: `phase2b_research_v3`; timing semantics: `phase2b_timing_semantics_v1`; run: `20260825T060535Z`
- Pre-development pytest baseline: **357 passed** (re-run for real).

## A. Timestamp Registry
- Registry: `phase2b_timing_semantics_v1`, 7 fields; frozen before viewing new-market aggregates: **True**.
- `binance_btc.exchange_timestamp_ms` -> BINANCE_TRADE_EXECUTION_TIME_T: **SOURCE_EVENT_TIME** / EVENT_LEVEL / trust HIGH / cross-source ordering LIMITED.
- `binance_btc.event_timestamp_ms` -> BINANCE_EVENT_DISPATCH_TIME_E: **SOURCE_EVENT_TIME** / EVENT_LEVEL / trust HIGH / cross-source ordering LIMITED.
- `binance_btc.receive_timestamp_ms` -> LOCAL_RECEIVE_AT_ON_TEXT: **LOCAL_RECEIVE_TIME** / BURST_QUANTIZED / trust MEDIUM / cross-source ordering YES.
- `polymarket_clob.exchange_timestamp_ms` -> POLYMARKET_CLOB_FRAME_TIMESTAMP: **SOURCE_FRAME_TIME** / FRAME_LEVEL / trust MEDIUM / cross-source ordering LIMITED.
- `polymarket_clob.receive_timestamp_ms` -> LOCAL_RECEIVE_AT_ON_TEXT: **LOCAL_RECEIVE_TIME** / FRAME_LEVEL / trust MEDIUM / cross-source ordering YES.
- `polymarket_clob.state_availability_ts` -> RECONSTRUCTED_STATE_AVAILABILITY: **RECONSTRUCTED_STATE_TIME** / EVENT_LEVEL / trust MEDIUM / cross-source ordering YES.
- `std0_fills.timestamp` -> STD0_FILL_TIME_SECOND_PRECISION: **SOURCE_EVENT_TIME** / SECOND_LEVEL / trust LOW / cross-source ordering NO.
- Local clock: **LOCAL_CLOCK_OFFSET_UNKNOWN** (offset never measured; retroactive correction FORBIDDEN).

## B. Raw Timestamp Semantics
- BTC `exchange_timestamp_ms` = Binance trade time T = SOURCE_EVENT_TIME (HIGH, event-level).
- PM `exchange_timestamp_ms` = CLOB per-frame server timestamp = SOURCE_FRAME_TIME (MEDIUM, FRAME_LEVEL): batched `price_changes[]` children inherit the parent frame timestamp; proven NOT last-trade time; never called exchange trade time.
- Both `receive_timestamp_ms` = LOCAL_RECEIVE_TIME on one local clock (BTC burst-quantized by the shared asyncio loop).
- std0 fills: SECOND_LEVEL; same-second ms ordering forbidden.

## C. BTC Timing Diagnostics
- receive minus T (n=100703): p50/p90/p99/max = 2539.0000/2602.0000/2781.0000/3157.0000 ms; MAD 136.0000 ms; fractions >250/>500/>1000/>5000ms = 0.5444/0.5344/0.5343/0.0000.
- Interpretation: EVENT_TRANSPORT_DELAY_PLUS_UNKNOWN_LOCAL_CLOCK_OFFSET (network-latency claim: False).
- Offset pattern: **CONSTANT_OFFSET_DOMINANT** - systematic local clock offset or buffered transport, NOT variable network latency
- p50 first/second half: 2551.0000/168.0000 ms; E-T p50 = 1.0000 ms.

## D. CLOB Timing Diagnostics
- receive minus frame timestamp (n=666813): p50/p90/p99/max = 403.0000/9088.0000/10726.0000/11221.0000 ms; MAD 219.0000 ms; fractions >250/>500/>1000/>5000ms = 0.5906/0.4576/0.3949/0.1801.
- Interpretation: FRAME_DELIVERY_DELAY_FRAME_TIME_BASIS (network-latency claim: False) - this is NOT event network latency; frame timestamps batch server-side and STATE_AGE is tracked separately.
- p50 first/second half: 2903.0000/239.0000 ms.

## E. Event-Type Breakdown (frame-basis delay)
- trade (BTC): n=100703, p50 2539.0000 ms, p99-p50 242.0000 ms, >1s 0.5343.
- book (PM): n=8728, p50 471.0000 ms, p99-p50 10263.7300 ms, >1s 0.4007.
- last_trade_price (PM): n=4115, p50 467.0000 ms, p99-p50 10317.6000 ms, >1s 0.4000.
- price_change (PM): n=653970, p50 401.0000 ms, p99-p50 10325.0000 ms, >1s 0.3947.
- market ...4e583e09 (BTC): p50 2551.0000 ms, p99-p50 291.0000 ms.
- market ...81d75679 (BTC): p50 170.0000 ms, p99-p50 59.4400 ms.
- market ...0c4bae56 (BTC): p50 164.0000 ms, p99-p50 223.0000 ms.
- market ...4e583e09 (PM): p50 4934.0000 ms, p99-p50 5841.0000 ms.
- market ...81d75679 (PM): p50 239.0000 ms, p99-p50 475.0000 ms.
- market ...0c4bae56 (PM): p50 220.0000 ms, p99-p50 10482.0000 ms.
- By market/connection and market/session rows: 4/4 (JSON report).

## F. State Age
- btc-updown-5m-1787590800: info age p50/p90/p99 = 9055.0000/54392.0000/81122.0000 ms; availability carry-forward p50 72.0000 ms; valid-but-not-fresh buckets 429.
- btc-updown-5m-1787594700: info age p50/p90/p99 = 226.0000/27488.0000/54443.0000 ms; availability carry-forward p50 5.0000 ms; valid-but-not-fresh buckets 117.
- btc-updown-5m-1787595000: info age p50/p90/p99 = 257.0000/87204.0000/114136.5000 ms; availability carry-forward p50 14.0000 ms; valid-but-not-fresh buckets 16.
- VALID is not FRESH: a still-VALID book state can carry seconds-old information; that age is never read as websocket network latency.

## G. Local Clock Health
- LOCAL_CLOCK_OFFSET_UNKNOWN; correction applied: False; retroactive correction: FORBIDDEN.

## H. Cross-source Comparability
- source-time basis: **LIMITED**; receive-time basis: **YES**; CAN_COMPARE_BTC_PM = **LIMITED**.
- source-time comparison is LIMITED: PM timestamps are per-frame server times (FRAME_LEVEL, not event times) and the Binance<->Polymarket server clock offset is unknown; receive-time comparison shares one local clock but mixes the two transport paths and the unknown local clock offset.

## I. Minimum Resolvable Lag
- Rule: max(p99-p50 of BTC, p99-p50 of CLOB receive-minus-source)
- Overall bound: **10323.0000 ms**; per-market bounds: btc-updown-5m-1787590800=5841.0000, btc-updown-5m-1787594700=10482.0000, btc-updown-5m-1787595000=475.0000.
- A 250ms peak under a 1000ms bound is BELOW_TIMING_RESOLUTION; never report 'exact lag = 250ms'.

## J. Source-time Lead-Lag (VIEW_A)
- Status: DESCRIPTIVE_ONLY_SOURCE_FRAME_TIME_SEMANTICS - descriptive only; PM source timestamps are frame times, not event times.
- btc-updown-5m-1787590800: METHOD_A 250ms -> **BTC_LEAD**; METHOD_B 5000ms; METHOD_C 0ms; agreement METHOD_CONSISTENT_MARKET.
- btc-updown-5m-1787594700: METHOD_A 250ms -> **BTC_LEAD**; METHOD_B 5000ms; METHOD_C 0ms; agreement METHOD_CONSISTENT_MARKET.
- btc-updown-5m-1787595000: METHOD_A 250ms -> **BTC_LEAD**; METHOD_B 5000ms; METHOD_C 0ms; agreement METHOD_CONSISTENT_MARKET.

## K. Receive-time Lead-Lag (VIEW_B)
- Both streams stamped by one local clock (burst-quantized); lag includes the transport-path difference.
- btc-updown-5m-1787590800: METHOD_A 500ms -> **BTC_LEAD**; METHOD_B 5000ms; METHOD_C 2000ms; agreement METHOD_CONSISTENT_MARKET.
- btc-updown-5m-1787594700: METHOD_A 500ms -> **BTC_LEAD**; METHOD_B 5000ms; METHOD_C 2000ms; agreement METHOD_CONSISTENT_MARKET.
- btc-updown-5m-1787595000: METHOD_A 500ms -> **BTC_LEAD**; METHOD_B 5000ms; METHOD_C 500ms; agreement METHOD_CONSISTENT_MARKET.

## L. Availability-time Lead-Lag (VIEW_C)
- No-backdating check: **PASS** across 3 markets.
- VIEW_C equivalence note: VIEW_C availability equals the constructing event's receive time for collector phase2a_prospective_v4 (synchronous single-loop reconstruction; no LOCAL_PROCESS_TIME recorded), so VIEW_C estimates equal VIEW_B numerically - asserted, not assumed; a future async collector would diverge and be caught by the no-backdating check.
- btc-updown-5m-1787590800: METHOD_A 500ms -> **BTC_LEAD** (timing trust TIER_D, resolution BELOW_TIMING_RESOLUTION, coarse bucket 0-500ms).
- btc-updown-5m-1787594700: METHOD_A 500ms -> **BTC_LEAD** (timing trust TIER_D, resolution BELOW_TIMING_RESOLUTION, coarse bucket 0-500ms).
- btc-updown-5m-1787595000: METHOD_A 500ms -> **BTC_LEAD** (timing trust TIER_D, resolution NEAR_TIMING_RESOLUTION, coarse bucket 0-500ms).

## M. Cross-clock Agreement
- Status: **CLOCK_BASIS_STABLE**; all three views agree on 3/3 markets; pairwise {'VIEW_A_vs_VIEW_B': {'agree': 3, 'disagree': 0}, 'VIEW_A_vs_VIEW_C': {'agree': 3, 'disagree': 0}, 'VIEW_B_vs_VIEW_C': {'agree': 3, 'disagree': 0}}.

## N. Dependence Sensitivity
- OVERLAPPING vs NON_OVERLAPPING_1S retained on every market; warnings on 3/3 markets.
- Pooled: warning=True, sign_flip=False, max_rel_diff=0.5417.

## O. Per-market Replication
- Markets: 3; direction counts {'BTC_LEAD': 3}; coarse buckets {'0-500ms': 3}.
- raw_btc_lead_fraction = **1.0000**; timing_resolved_btc_lead_fraction = **0.0000**.
- Cluster awareness: {'shock_count': 667, 'market_count': 3, 'day_count': 1} (effective evidence ~ market count, not shock count).

## P. B1 Milestones
- Evidence state: **EARLY_REPLICATION**; n_markets=3; attained v3 milestones [3]; next 10.
- M3 auto-gate fired at >=3 full-lifecycle v4 markets without waiting for user instruction: **already_present**.

## Q. B2 Status
- **INSUFFICIENT_STD0_EVENTS** - 0 eligible std0 observations; second-level floor unchanged; B2 can never validate a 250ms reaction.

## R. O3 Recorder Status
- Supervisor active: False (exit reason SHUTDOWN_REQUESTED); analysis ran OFFLINE on closed files only; recorder priority rule untouched.
- Recorder reliability gate (v3.1): **MEMORY_HOTFIX_PASS** - engineering fix `recorder_reliability_fix_v1` (8 items); collector version unchanged: phase2a_prospective_v4; version bump required: False; recorder state: **RECORDER_READY**.
- Raw inputs: 9 closed SHA-verified files; active unclosed files excluded: 0 (ACTIVE_FILE_NO_SIDECAR != SHA_FAILURE); closed missing sidecar 0; SHA failures 0.

## S. v2 +250ms Reassessment
- v2 artifact: `D:\工作\量化\std0-quant\data\reports\phase2b_research_20260824T184008Z.json` - 1 market(s), METHOD_A lag 250ms, direction BTC_LEAD.
- v3 inputs: 3 markets, 3 BTC_LEAD, 0 timing-resolved (ABOVE_TIMING_RESOLUTION).
- Outcome: **DIRECTIONALLY_ROBUST_BUT_LAG_UNRESOLVED** (V2_RESULT_DIRECTIONALLY_ROBUST_BUT_LAG_UNRESOLVED)
- Reasoning: direction replicated by strict majority but the lag is not timing-resolved (ambiguity at or above the measured lag); the direction stands, the magnitude does not
- CONFIRMED_250MS is not in the vocabulary and was not output.

## T. Decision
- Timing decision: **TIMING_SEMANTICS_LIMITED + TIMING_RESOLUTION_INSUFFICIENT**
- Timing confidence: **LOW** (direction consistent with limited semantics never upgrades trust tiers or confidence).
- Overall: **TIMING_SEMANTICS_LIMITED + TIMING_RESOLUTION_INSUFFICIENT**

No causal, alpha, profitability, execution or trading conclusion is authorized.
DIRECTION MAY REPLICATE BEFORE MAGNITUDE IS IDENTIFIED: report the Level 1 direction, keep Level 2 UNRESOLVED while the peak is below the timing-resolution bound, and treat Level 3 grid peaks as descriptive only.

## U. Interpretation (v3.1 hierarchy)
- Direction status: **DIRECTION_REPLICATED_EARLY**; lag magnitude status: **LAG_MAGNITUDE_UNRESOLVED**.
- Guard: peak 250 vs resolution 10323.0000 -> LAG_MAGNITUDE_UNRESOLVED; unsupported magnitude wording is rejected before publication.
- Supported conclusion: Across the 3 estimated eligible prospective_v4 markets, the dominant association is BTC_LEAD on all three clock views; however, the measured peak lags are below the current timing-resolution bound, so the lag magnitude is unresolved.
- Interpretation erratum: `D:\工作\量化\std0-quant\data\reports\phase2b_v3_interpretation_erratum_20260825T055232Z.json` (immutable v3 reports unchanged; INTERPRETATION_PRECISION_CORRECTION).
- btc-updown-5m-1787590800: L1 **BTC_LEAD** / L2 UNRESOLVED (LAG_MAGNITUDE_UNRESOLVED) / L3 peak 250ms = DESCRIPTIVE_ONLY.
- btc-updown-5m-1787594700: L1 **BTC_LEAD** / L2 UNRESOLVED (LAG_MAGNITUDE_UNRESOLVED) / L3 peak 250ms = DESCRIPTIVE_ONLY.
- btc-updown-5m-1787595000: L1 **BTC_LEAD** / L2 UNRESOLVED (LAG_MAGNITUDE_UNRESOLVED) / L3 peak 250ms = DESCRIPTIVE_ONLY.
- Descriptive metrics (never timing conclusions while below resolution): per-market METHOD_A peaks {'btc-updown-5m-1787590800': 250, 'btc-updown-5m-1787594700': 250, 'btc-updown-5m-1787595000': 250}; per-market receive-view peaks {'btc-updown-5m-1787590800': 500, 'btc-updown-5m-1787594700': 500, 'btc-updown-5m-1787595000': 500}.
- CAPTURE NEW EVIDENCE BEFORE ADDING NEW EXPLANATIONS.
