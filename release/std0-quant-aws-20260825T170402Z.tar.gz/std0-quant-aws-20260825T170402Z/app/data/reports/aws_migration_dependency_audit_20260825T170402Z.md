# AWS Migration Dependency Audit

- Run: `20260825T170402Z`
- Source: `https://github.com/ellissun8-lab/Polymarket-quant.git` (public repository currently empty)
- Source working directory is not a Git worktree; `git_commit = null`.
- Tests: **459 baseline → 461 final; 5/5 repeated full-suite PASS**
- Settings SHA-256: `580abdc9a7ea5e34cc854d1ded12de35703bfcbbf2f216b1020a04cd6a0b05ae`

## Required runtime paths

- `src/std0_quant/**`
- `scripts/run_live_supervisor.py`
- `scripts/collect_live.py`
- `scripts/live_status.py`
- `scripts/report_live_coverage.py`
- `scripts/report_market_coverage.py`
- `scripts/init_prospective_baseline.py`
- `config/settings.yaml`
- `pyproject.toml`
- `data/derived/event_ledger.parquet`
- `data/state/baseline_truth_snapshot.json`
- `data/state/eligibility_policy_freeze_prospective_v4_eligibility_v2.json`
- `data/state/primary_cohort_freeze_prospective_v4.json`
- `data/state/prospective_cohort.json`

## Optional / historical paths

- `tests/**`
- `README.md`
- `.env.example`
- `selected data/reports/**`
- `data/state/migration_history/** (NOT_RUNTIME_STATE)`

## Excluded

- `data/raw/**` — historical and active raw remain on Windows
- `data/sessions/**` — old process/session lineage must not migrate
- `data/logs/**` — Windows operational logs
- `data/state/supervisor_status.json` — stale/active PID state
- `data/state/live_health.json` — live runtime snapshot
- `data/state/network_health.json` — live runtime snapshot
- `data/state/manifest_supervisor-*.json` — old session identity
- `data/state/sync_state.db` — 506MB historical sync state; recorder-only bundle
- `data/normalized/**` — offline/rebuildable historical analysis data
- `data/derived/** except event_ledger.parquet` — offline/rebuildable analysis data
- `data/reports/** except selected authoritative evidence` — large/redundant reports
- `data_fixture/**` — development fixture, not recorder runtime
- `notebooks/**` — offline analysis only
- `.venv/**, venv/**, env/**` — platform-specific virtual environments
- `**/__pycache__/**, **/*.py[co], .pytest_cache/**` — cache/bytecode
- `.env and credential/key patterns` — secret safety

## Key conclusions

- Historical/active raw and old session state are not recorder dependencies for a clean AWS session.
- `event_ledger.parquet` plus the frozen baseline snapshot are required by supervisor startup validation.
- Historical trade sync/derived refresh needs excluded multi-GB history; the minimal successor-recorder workflow is recorder-only.
- Proxy routing is obtained from OS/environment settings. Direct operation is supported when proxy variables are absent.
- `AWS_PROXY_MIGRATION_REQUIRED = true`: review/unset Windows localhost proxy variables; source/config does not hard-code `127.0.0.1:7892`.
- Python 3.14 compatibility is `UNKNOWN`: metadata and current Linux wheels are available, but the validated source runtime is Python 3.12.10.
