# Reconciliation report

- raw markets: 72026
- markets with trades: 72026
- markets with BUY trades: 69253
- markets with FirstOpposite: 54731
- clean markets: 23213
- excluded markets: 48813

## Exclude reasons

- BTC_DATA_MISSING: 200
- FIELD_INCOMPLETE: 2773
- MARKET_METADATA_MISSING: 1
- OTHER: 44974
- SAME_SECOND_DIRECTION_AMBIGUITY: 865

## Y30 (markets with FirstOpposite)

- positives: 14331
- negatives (horizon eligible): 5535
- censored (horizon ineligible): 18

## Problems

- none
