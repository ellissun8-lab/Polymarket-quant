# v4 Full-Lifecycle Validation

- Market: `btc-updown-5m-1787590800`
- BTC coverage: 0.996667
- Book coverage: 1.000000
- In-market stale (BTC/book): 0/0
- Post-market stale (BTC/book): 1/0
- Result: **PASS**
