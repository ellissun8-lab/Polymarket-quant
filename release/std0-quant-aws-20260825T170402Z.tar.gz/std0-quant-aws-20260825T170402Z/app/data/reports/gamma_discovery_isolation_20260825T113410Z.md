# Gamma Discovery Isolation Audit

Run ID: `20260825T113410Z`

Decision: `GAMMA_DISCOVERY_ISOLATION_FIX_PASS`

Supporting decisions: `GAMMA_EVENT_LOOP_BLOCKING_CONFIRMED`, `GAMMA_BLOCKING_CONTRIBUTED_TO_BOOK_GAPS`, `O3_RESTART_REQUIRED`.

## Root cause and old call path

The Book orchestration coroutine called the synchronous Gamma HTTP stack directly:

`LiveCollector.run_book_forever` → `wait_for_next_market` → `discover_market` → `find_active_market` → `_fetch_market_by_slug` → `requests.Session.get(timeout=30)`.

That placed DNS, configured-proxy negotiation, TLS/connect, response read, and parsing on the same asyncio thread used by CLOB frame handling and the stale watchdog. Retry waits were already non-blocking asyncio waits; the synchronous HTTP call and its exception-path proxy probe were the blocking parts. The existing 30-second request timeout and configured proxy route were not changed.

## Deterministic blocking proof

The regression fixture runs a 10 Hz event-loop ticker while Gamma blocks for six seconds.

| Implementation | Gamma duration | Maximum loop scheduling gap | Result |
|---|---:|---:|---|
| Old | 6.0005 s | 6000.0 ms | Book/data-plane scheduling starved for the Gamma delay |
| New | 6000.378 ms | 125.0 ms | No multi-second starvation; acceptance bound 350 ms |

Before implementation, the new isolation suite produced `11 failed / 3 passed`. After implementation, `GI1–GI14` all pass.

## Fix architecture

Gamma discovery now runs in one dedicated, bounded `ThreadPoolExecutor` worker. A serialized generation gate provides:

- maximum worker concurrency of one;
- target-market identity validation;
- stale queued/in-flight result discard with journaling;
- exact-once application for a correct target;
- duplicate and target-mismatch suppression;
- exception and proxy-diagnostic containment without stopping BTC or CLOB recorders.

Session telemetry records Gamma apply/error/stale/mismatch/duplicate events and `event_loop_lag_ms` p50/p95/p99/max. No large framework was introduced.

## Historical gap decomposition

| Market | Total gaps | Gamma-blocked estimate | Remaining network/reconnect | Attribution |
|---|---:|---:|---:|---|
| 1787652900 | 30.448 s | 5.915 s | 24.533 s | Slow-consumer causal contribution `UNKNOWN` |
| 1787653200 | 23.321 s | 5.811 s | 17.510 s | Direct Gamma cause of the separate ping timeout `NOT_SUPPORTED` |
| 1787653500 | 5.827 s | 5.827 s | 0 s | Same connection; gap end within 2 ms of Gamma completion |

The fix removes the confirmed local control-plane blocking component. It does not claim to remove remote closes, slow-consumer behavior, watchdog recovery, ping timeout, handshake, or snapshot-readiness time.

## Invariants and tests

- Tests: `445 passed` baseline → `459 passed` final.
- Gamma isolation: `14 passed`, covering GI1–GI14 including the multi-rotation soak.
- 99% gate: unchanged.
- Coverage evidence: `coverage_evidence_v2`, unchanged.
- `receive_timestamp_ms` and `exchange_timestamp_ms`: unchanged.
- Raw receive timestamp is currently captured at async Book handler start. It cannot measure pre-dispatch socket waiting without a separate timestamp-semantics change, so this fix does not introduce a misleading `book_receive_to_process_delay_ms`; event-loop lag is recorded separately.
- Settings SHA-256: `580abdc9a7ea5e34cc854d1ded12de35703bfcbbf2f216b1020a04cd6a0b05ae`.
- Historical coverage/rotation/repair/old-acceptance artifacts were verified unchanged by SHA-256.

## Versions and prospective consequence

- Collector: `phase2a_prospective_v4`.
- Engineering fixes: `recorder_reliability_fix_v1`, `network_stability_fix_v1`, `coverage_selection_fix_v1`, `gamma_discovery_isolation_fix_v1`.
- Coverage evidence: `coverage_evidence_v2`.
- Eligibility: `prospective_v4_eligibility_v2`.
- Primary cohort: unchanged.
- M10: `3/10`.
- B2: `0`.

At audit time, both the supervisor PID 13792 and collector PID 20404 were absent, although `supervisor_status.json` still said active and the journal had no `session_end`. These state files are stale; no recorder process was stopped or restarted by this audit. The old session remains unusable for final O3.

The next manually started session must prove that all version components above are loaded. O3 then starts at `0/86400` without stitching, and post-fix acceptance requires the first three consecutive `FULL_LIFECYCLE` markets from that new session.

**DO NOT RESTART RECORDER AUTOMATICALLY.**
