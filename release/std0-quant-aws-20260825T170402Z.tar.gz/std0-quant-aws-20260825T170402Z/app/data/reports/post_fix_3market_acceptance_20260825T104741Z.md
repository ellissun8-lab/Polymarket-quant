# Post-Fix 3-Market Acceptance

- Run: `20260825T104741Z`
- Tests: `430 passed`
- Session: `supervisor-1787652746725-13792` (active; supervisor PID 13792 and collector PID 20404 alive)
- Runtime snapshot: `2114.906 / 86400` seconds
- Versions: `phase2a_prospective_v4` / `network_stability_fix_v1` / `prospective_v4_eligibility_v2`
- Effective-from: frozen at this session; retroactive expansion remains `FORBIDDEN`

## First three consecutive full markets

| # | Market | Lifecycle | Ready start/end | BTC formal | BTC active-file sensitivity | Book | BTC/CLOB WS reconnects | Full restarts | Gaps BTC/Book (s) | Eligibility | Primary reason |
|---:|---|---|---|---:|---:|---:|---:|---:|---:|---|---|
| 1 | `btc-updown-5m-1787652900` | FULL_LIFECYCLE | yes/yes | 0.0000 (invalid artifact) | 0.993333 | 0.946667 | 0 / 3 | 0 | 5.981 / 30.448 | EXCLUDED | BOOK_COVERAGE_LT_99 |
| 2 | `btc-updown-5m-1787653200` | FULL_LIFECYCLE | yes/yes | 0.0000 (invalid artifact) | 0.996667 | 0.950000 | 0 / 1 | 0 | 5.787 / 23.321 | EXCLUDED | BOOK_COVERAGE_LT_99 |
| 3 | `btc-updown-5m-1787653500` | FULL_LIFECYCLE | yes/yes | 0.0000 (invalid artifact) | 0.990000 | 0.993333 | 0 / 0 | 0 | 5.847 / 5.827 | EXCLUDED | ROTATION_COVERAGE_FAILURE |

The formal BTC values are not treated as real capture coverage. All three generated reports contain `btc_files=[]`. A read-only sensitivity scan of the still-active BTC raw file shows the feed crossed all three markets at or above the frozen 99% threshold, but active-file sensitivity cannot replace formal closed-file evidence.

## Rotation and readiness

| Market | Prediscovery lead | Subscribed before start | Dual-token valid before start | Status |
|---|---:|---:|---:|---|
| `1787652900` | 25.017 s | 9.060 s | 8.732 s | Gamma retry recovered; ready before start |
| `1787653200` | 54.128 s | 8.789 s | 8.378 s | ready before start |
| `1787653500` | 54.391 s | 8.996 s | 8.577 s | ready before start |

Gamma discovery for the first market required two attempts: one `PROXY_CONNECTION_REFUSED`, then successful discovery. It did not exit `collect_live`. The three formal markets had four CLOB WS reconnect schedules in total and zero BTC WS reconnects; these are distinct from the zero full collector restarts. Restart storm state remained `NORMAL`.

## Integrity, queue, and memory

- Closed Book raw: 6 `NORMAL_CLOSED`, 6 sidecars, 0 missing sidecars, 0 SHA failures, 0 parse errors.
- BTC raw: 1 `ACTIVE`; absence of its sidecar is not a SHA failure. Formal BTC SHA remains pending file close.
- Queue: capacity 1000, drops 0. `QUEUE_HIGH_WATER_TELEMETRY_UNAVAILABLE` is a non-blocking telemetry limitation.
- RSS: start unavailable; sparse samples 63.0, 60.0, 43.3 MB; p50 60.0, p95 62.7, max 63.0 MB. `SHORT_LIVE_MEMORY_REGRESSION_PASS`; this is not a 24-hour soak result.
- Watchdog: stale detection evidence uses local receive inactivity; no false positive or full collector restart was found.

## Confirmed acceptance-chain bug

Real logs prove an implementation defect in active-session coverage selection: an unterminated connected interval is represented as `(connected_at, connected_at)`. Consequently, `session_overlaps` returns false for later market windows, the coverage subprocess excludes the active BTC file, and every post-fix report emits zero BTC coverage. No code was changed in this audit, per the read-only instruction.

## Milestones and decision

- M10: `3/10`; no new primary eligible markets and no trigger.
- B2-N001: `0`; no trigger.
- O3: `2114.906/86400`, `O3_ACCUMULATING`, same session only, no stitching.

Decision:

`NETWORK_STABILITY_PARTIAL`

Supporting statuses:

- `NETWORK_ERRORS_CONTAINED`
- `ROTATION_COVERAGE_FAILURE`
- `O3_ACCUMULATING`

Live accumulation continues. The strong 3/3 coverage PASS condition is not met.
