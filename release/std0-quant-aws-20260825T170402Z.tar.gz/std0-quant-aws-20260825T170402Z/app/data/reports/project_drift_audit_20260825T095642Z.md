# std0-quant Project Drift Audit

| Track | Milestone | Current | Target | Status |
|---|---|---:|---:|---|
| Recorder post-fix | PF1 | 0 | 1 | PENDING |
| 3-market validation | PF3 | 0 | 3 | PENDING |
| O3 | O3 | 0.0 | 86400 | NOT_STARTED |
| M10 | B1-M10 | 3 | 10 | ACCUMULATING |
| B2 N001 | B2-N001 | 0 | 1 | ACCUMULATING |
| C100 | C100 | 0 | 100 | ACCUMULATING |
| C500 | C500 | 0 | 500 | ACCUMULATING |
| C1000 | C1000 | 0 | 1000 | ACCUMULATING |
| N5000 | FINAL-N5000 | 0 | 5000 | ACCUMULATING |
| D14 | FINAL-D14 | 0 | 14 | ACCUMULATING |
| Phase2A revalidation | PHASE2A-REVALIDATION | 0 | 1 | PENDING |
| Phase2B Confirmed | PHASE2B-CONFIRMED | 0 | 1 | NOT_AUTHORIZED |
| Strategy | STRATEGY-V1-FREEZE | 0 | 1 | NOT_AUTHORIZED |

## A. Tests
- 430 passed, 0 failed; git_status=NOT_AVAILABLE.

## B. Core Frozen Truth
- PHASE1_FROZEN_TRUTH = **PASS**; historical rows changed=0; evolving new rows=324.

## C. Phase-by-Phase Drift
- DRIFT-001 [LOW] GOVERNANCE_CHANGE: Phase2B-Research exploratory may run in parallel; Confirmed remains unauthorized
- DRIFT-002 [MEDIUM] METHODOLOGY_CORRECTION: Direction replicated early; lag magnitude unresolved
- DRIFT-003 [HIGH] COHORT_GOVERNANCE_CHANGE: Endpoint readiness plus independent 99% gap gate
- DRIFT-004 [LOW] DOCUMENTATION_DRIFT: Actual suite count is current runtime collection
- DRIFT-005 [MEDIUM] VERSIONING_DRIFT: Recorded PID does not exist; health/status are stale
- DRIFT-006 [HIGH] METHODOLOGY_CORRECTION: Episode end is only observable after >3s silence
- DRIFT-007 [HIGH] DATA_INTEGRITY_FAILURE: 2 orphan files lack sidecars; SHA failures=0

## D. Engineering Evolution
- prospective_v1→v4 were versioned recorder engineering changes; older artifacts remain preserved.
- recorder_reliability_fix_v1 changed allocation/fault isolation, not research truth.
- network_stability_fix_v1 adds retry/backoff/isolation; real PF1/PF3 validation is still pending.

## E. Governance Evolution
- Phase2B-Research is AUTHORIZED_EXPLORATORY; Confirmed/Strategy/PnL/Execution/Trading remain NOT_AUTHORIZED.
- eligibility v2 is prospective-only; effective-from freeze awaits the first loaded post-fix session.

## F. Methodology / Interpretation Corrections
- v3/v3.1 supersede exact +250ms/0–2s interpretation: direction early, magnitude unresolved.
- Deployability must distinguish first_opp_end label anchor from episode-completion observability.

## G. Cohort Versioning
- **COHORT_VERSIONING_PASS**; v1/v2/v3 are not primary; eligibility v2 boundary is pending PF1 and no historical row was added.

## H. Retrospective Selection Audit
- A_Y30_CHANGED_AFTER_RESULTS: **NO**
- B_EPISODE_GAP_CHANGED_AFTER_RESULTS: **NO**
- C_99_PERCENT_GATE_LOWERED: **NO**
- D_OLD_VERSION_MARKETS_BACKFILLED_FOR_M10: **NO**
- E_HIGH_LATENCY_MARKETS_DELETED: **NO**
- F_LAG_GRID_RETUNED_AFTER_250MS: **NO**
- G_FEATURE_LIST_CHANGED_BY_Y30_RESULT: **NO**

## I. Documentation Drift
| Document | Statement | Current governance | Severity |
|---|---|---|---|
| README.md:61,219,484,543,594 | 330/357/398 described as current or nearby baselines | 430 collected tests | LOW |
| src/std0_quant/__init__.py and pyproject.toml | Phase 1 scope only | Phase1 truth plus Phase1.5/1.6, Phase2A and exploratory Phase2B; no trading | LOW |
| data/state/supervisor_status.json | active=true | PID absent; recorder stopped/stale state | MEDIUM |

## J. Raw Integrity
- Closed/verified candidates=367; active=0; orphan unfinalized=2; closed missing sidecars=2; SHA failures=0; parse errors=0; queue drops=0.

## K. Current Recorder State
- {'reported_active': True, 'actual_process_alive': False, 'actual_active': False, 'session_id': 'supervisor-1787646405237-19208', 'engineering_fix_version': 'recorder_reliability_fix_v1', 'eligibility_policy_version': None, 'health_status': 'STALE', 'btc_health': 'STALE', 'book_health': 'STALE', 'proxy_health': None}

## L. Current Evidence
- B1=EARLY_REPLICATION; markets=3; raw/timing-resolved BTC lead=1.0/0.0; B2=0.

## M. Milestone Dashboard
- P1: PASS/PASS — **PASS**
- P15: PASS/PASS — **PASS**
- P16: GO/GO — **PASS**
- A0: PASS/PASS — **PASS**
- L1: PASS/PASS — **PASS**
- O1: 1/1 — **PASS**
- MEM1: 8/8 — **PASS**
- NET1: 13/13 — **PASS**
- PF1: 0/1 — **PENDING**
- PF3: 0/3 — **PENDING**
- O2: 0/1 — **ACCUMULATING**
- O3: 0.0/86400 — **NOT_STARTED**
- B1-M3: 3/3 — **PASS**
- B1-M10: 3/10 — **ACCUMULATING**
- B1-M20: 3/20 — **ACCUMULATING**
- B1-M50: 3/50 — **ACCUMULATING**
- B1-M100: 3/100 — **ACCUMULATING**
- B2-N001: 0/1 — **ACCUMULATING**
- B2-N010: 0/10 — **ACCUMULATING**
- B2-N050: 0/50 — **ACCUMULATING**
- B2-N100: 0/100 — **ACCUMULATING**
- B2-N250: 0/250 — **ACCUMULATING**
- B2-N500: 0/500 — **ACCUMULATING**
- C100: 0/100 — **ACCUMULATING**
- C500: 0/500 — **ACCUMULATING**
- C1000: 0/1000 — **ACCUMULATING**
- FINAL-N5000: 0/5000 — **ACCUMULATING**
- FINAL-D14: 0/14 — **ACCUMULATING**
- PHASE2A-REVALIDATION: 0/1 — **PENDING**
- PHASE2B-CONFIRMED: 0/1 — **NOT_AUTHORIZED**
- STRATEGY-V1-FREEZE: 0/1 — **NOT_AUTHORIZED**
- OOS-STRATEGY: 0/1 — **NOT_AUTHORIZED**

## N. Remaining Risk Register
- R1 [HIGH] OPEN: Proxy dependency instability
- R2 [HIGH] OPEN: Timing resolution insufficient
- R3 [HIGH] KNOWN_LIMITATION: std0 timestamps are second-level
- R4 [MEDIUM] MONITORED: Coverage selection bias
- R5 [HIGH] OPEN: Cohort maturity is 0/5000 and 0/14 days
- R6 [LOW] OPEN: Documentation/current-state drift
- R7 [HIGH] OPEN: 3-second episode completion is not observable at label anchor
- R8 [MEDIUM] NOT_AUTHORIZED: Future fee/rebate version uncertainty
- R9 [HIGH] NOT_AUTHORIZED: Future execution latency/queue uncertainty

## O. Critical Path
1. User manually starts a supervisor that loads network_stability_fix_v1 and eligibility v2 (PF1).
2. Observe three consecutive closed post-fix full-lifecycle markets without changing the 99% gate (PF3).
3. Keep that session running; audit M10, N001 and O3 independently as they naturally trigger.

## P. Decision
- **NO_MATERIAL_RESEARCH_DRIFT + ENGINEERING_EVOLUTION_PRESENT + GOVERNANCE_EVOLUTION_PRESENT + DOCUMENTATION_DRIFT_PRESENT + METHODOLOGY_CORRECTIONS_PRESENT**
- CORE_RESEARCH_DRIFT: NONE
- DOCUMENTATION_DRIFT: PRESENT
- OPEN_OPERATIONAL_RISKS: PF1/PF3 pending; stale state and two orphan unfinalized files; proxy and O3 unresolved.

项目没有发生实质性研究跑偏；工程、治理与方法解释发生了有审计轨迹的演化，冻结标签和正式门槛保持不变，但 post-fix 实盘验证、状态清理与 raw 封口仍待完成。
