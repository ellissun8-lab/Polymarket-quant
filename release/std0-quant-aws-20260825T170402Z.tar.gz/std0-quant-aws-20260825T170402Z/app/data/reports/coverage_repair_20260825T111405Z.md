# Historical Coverage Evidence Repair Audit

## Decision

`BTC_FORMAL_EVIDENCE_REPAIRED`

The source BTC hourly file closed normally, published a sidecar, and passed SHA-256 verification (`571a4a54febd0fd1c60fdc482140677762e0ac4df113743890f994c0a94b8776`). Deterministic v2 repair artifacts were generated without overwriting the old zero-coverage reports.

| Market | BTC buckets | Formal BTC | Book buckets | Formal Book | Engineering result |
|---|---:|---:|---:|---:|---|
| 1787652900 | 298/300 | 99.3333% PASS | 284/300 | 94.6667% FAIL | BTC repaired; Book failure retained |
| 1787653200 | 299/300 | 99.6667% PASS | 285/300 | 95.0000% FAIL | BTC repaired; Book failure retained |
| 1787653500 | 297/300 | 99.0000% PASS | 298/300 | 99.3333% PASS | formal evidence passes |

The 99% boundary is evaluated using integer bucket counts: `297 >= 0.99 × 300`, so 297/300 passes exactly. The 98.9% regression fixture fails.

The old acceptance remains `NETWORK_STABILITY_PARTIAL`: markets 1 and 2 retain real Book failures, and corrected historical engineering evidence is not permission to expand the primary cohort. M10 remains 3/10 and B2 remains 0.

All old reports, pending artifacts, raw files, sidecars, and journals remain immutable. Repeating finalization produces the same content-addressed artifact.
