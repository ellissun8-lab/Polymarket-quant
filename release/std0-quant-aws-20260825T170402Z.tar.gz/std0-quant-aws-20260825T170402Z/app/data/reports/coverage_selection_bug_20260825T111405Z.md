# Coverage Evidence Selection Bug Audit

## Result

`COVERAGE_SELECTION_BUG_CONFIRMED` + `COVERAGE_SELECTION_FIX_PASS`

- Baseline: 430 passed.
- Regression fixture before the fix: 14/14 failed.
- New CF/RF tests: 15.
- Final suite: 445 passed.

## Root cause and repaired semantics

The old implementation represented an active connection as `(connected_at, connected_at)`. A later market therefore did not overlap the live BTC session and the report worker selected no BTC files. It also kept the close timestamp as a new open floor, creating redundant intervals after disconnect/session end.

The repaired interval is `[start, None]`, with overlap defined as `start <= market_end` and `(end is None or end >= market_start)`. File selection also requires file-level temporal overlap, preventing finalized orphan files from being treated as open forever.

Coverage evidence now has three formal states:

- `FINAL_PASS_OR_FAIL`: closed, sidecar present, SHA verified.
- `PENDING_ACTIVE_SOURCE_FILE`: candidate data is still active; formal coverage is null.
- `SOURCE_NOT_CAPTURED`: no candidate raw source exists.

Active-file scans are labeled `PROVISIONAL_ACTIVE_FILE` and cannot authorize primary eligibility. Pending is never encoded as zero.

## Version and invariants

- Coverage evidence: `coverage_evidence_v2`.
- Engineering fix: `coverage_selection_fix_v1`.
- Collector remains `phase2a_prospective_v4`.
- Network fix remains `network_stability_fix_v1`.
- Eligibility remains `prospective_v4_eligibility_v2`.
- Settings SHA-256 remains `580abdc9a7ea5e34cc854d1ded12de35703bfcbbf2f216b1020a04cd6a0b05ae`.
- The old acceptance JSON/Markdown and all raw/sidecar/journal data were not modified.

## Runtime consequence

The active supervisor does not contain the new coverage version metadata, while future coverage subprocesses load the changed files from disk. The current session can continue recording raw data, but it is a mixed-implementation O3 candidate.

`O3_RESTART_REQUIRED`; Codex did not stop or restart the recorder.
