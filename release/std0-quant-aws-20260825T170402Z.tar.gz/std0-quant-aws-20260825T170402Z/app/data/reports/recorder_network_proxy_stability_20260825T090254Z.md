# Recorder Network / Proxy Stability Audit

## A. Tests
- Baseline: **398 passed**; post-fix: **411 passed**

## B. Session analyzed
- supervisor-1787637997224-16860: 4308.825s, exit=SHUTDOWN_REQUESTED

## C. Proxy configuration
- Source: SYSTEM_OR_ENVIRONMENT_PROXY_POLICY; 127.0.0.1:7892; current=PROXY_HEALTHY
- Binance WS, Polymarket WS and Gamma HTTP all resolve through the same configured proxy. No direct fallback is used.

## D. Connection error taxonomy
- BTC / CONNECT / PROXY_CONNECTION_REFUSED / ConnectionRefusedError: **258**
- BTC / CONNECT / PROXY_TIMEOUT / TimeoutError: **1**
- BTC / READ / REMOTE_CLOSE / ConnectionClosedError: **1**
- CLOB / READ / PING_TIMEOUT / ConnectionClosedError: **12**
- CLOB / READ / REMOTE_CLOSE / ConnectionClosedError: **17**

## E. Restart taxonomy
- Full collect_live restarts: **271**; exit codes={'0': 256, '1': 8, '3221225794': 1, '3221225773': 5, '120': 1}
- Runtime p10/p50/p90: 5.044/5.062/5.105s; under 10s=256

## F. Restart storm analysis
- RESTART_STORM_WARNING: 60 restarts in the busiest rolling 5-minute window.

## G. BTC connection health
- {'successful_connections': 2, 'failed_connections': 260, 'lifetime_seconds': {'p10': 843.2733000000001, 'p50': 1259.6825, 'p90': 1676.0917}, 'median_reconnect_delay_seconds': 6.976}

## H. CLOB connection health
- {'successful_connections': 38, 'failed_connections': 29, 'lifetime_seconds': {'p10': 18.417299999999997, 'p50': 48.348, 'p90': 118.16130000000007}, 'median_reconnect_delay_seconds': 8.352}

## I. Watchdog semantics
- PASS: stale detection uses local receive activity, not source/frame timestamp.

## J. Market rotation
- Prediscovery was configured, but a single Gamma/proxy failure could previously abort the book task; the fix retries through the prediscovery window.

## K. Snapshot readiness
- `book_state_valid` requires reconstructed snapshots for both tokens; socket CONNECTED alone is not treated as ready.

## L. Per-market coverage root causes
- btc-updown-5m-1787637900: lifecycle=PARTIAL_SESSION_MARKET; BTC=0.5600; book=0.5133; eligible=False; reasons=['PARTIAL_SESSION_START', 'SESSION_ENDED_EARLY', 'BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NO_VALID_SNAPSHOT_AT_START', 'NETWORK_GAP', 'MARKET_DISCOVERY_LATE', 'ROTATION_GAP']
- btc-updown-5m-1787638200: lifecycle=FULL_LIFECYCLE_MARKET; BTC=0.9333; book=0.9733; eligible=False; reasons=['BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787638500: lifecycle=FULL_LIFECYCLE_MARKET; BTC=0.9333; book=0.9533; eligible=False; reasons=['BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787638800: lifecycle=PARTIAL_SESSION_MARKET; BTC=0.9533; book=0.8833; eligible=False; reasons=['SESSION_ENDED_EARLY', 'BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787639100: lifecycle=FULL_LIFECYCLE_MARKET; BTC=0.9233; book=0.8100; eligible=False; reasons=['BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787639400: lifecycle=FULL_LIFECYCLE_MARKET; BTC=0.9167; book=0.8633; eligible=False; reasons=['BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787639700: lifecycle=FULL_LIFECYCLE_MARKET; BTC=0.9133; book=0.9900; eligible=False; reasons=['BTC_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787640000: lifecycle=FULL_LIFECYCLE_MARKET; BTC=0.9133; book=0.9233; eligible=False; reasons=['BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP']
- btc-updown-5m-1787640300: lifecycle=PARTIAL_SESSION_MARKET; BTC=0.7167; book=0.6467; eligible=False; reasons=['SESSION_ENDED_EARLY', 'BTC_COVERAGE_LT_99', 'BOOK_COVERAGE_LT_99', 'NETWORK_GAP', 'PROXY_OUTAGE']

## M. Eligible market analysis
- New eligible markets: **0**; breakdown={'markets': 9, 'lifecycle_fail': 3, 'btc_lt_99': 9, 'book_lt_99': 8, 'both_coverage_fail': 8, 'network_gap': 9, 'rotation_gap': 1, 'session_boundary': 3, 'proxy_outage': 1}

## N. Engineering fixes
- Gamma/proxy exceptions are contained and retried without terminating BTC.
- Next-market prediscovery retries through the overlap window.
- Unexpected collector task failure now returns non-zero.
- Supervisor full-child restarts gain exponential backoff and RESTART_STORM_WARNING health telemetry.
- Proxy dependency state is recorded without direct fallback.
- Watchdog retains local-receive-time semantics.
- Closed-market coverage scanning runs below-normal in a separate process to avoid event-loop/GIL starvation.
- Lifecycle uses endpoint readiness; reconnect gaps remain governed independently by the unchanged 99% coverage gate.

## O. Raw integrity
- Sidecars 272/272; SHA failures=0; parse errors=0.

## P. Real live validation
- PENDING_POST_FIX_RESTART; currently running supervisor loaded before this fix and was not stopped.

## Q. O3 state
- PENDING_INTERRUPTED

## R. M10 progress
- 3 / 10

## S. B2 status
- 0

## T. Decision
- **PROXY_ENVIRONMENT_UNSTABLE + ROTATION_COVERAGE_BUG_FOUND + NETWORK_STABILITY_PARTIAL**
