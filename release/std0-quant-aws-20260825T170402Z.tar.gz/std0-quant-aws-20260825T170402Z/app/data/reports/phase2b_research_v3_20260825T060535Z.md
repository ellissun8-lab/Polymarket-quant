# Phase 2B Research - Per-Market Lead-Lag Stability Audit

**EXPLORATORY RESEARCH ONLY - NO REAL TRADING**

## A. Governance
- Phase 2B-Research: **AUTHORIZED_EXPLORATORY**; Confirmed/strategy/execution/trading: **NOT_AUTHORIZED**
- Research spec: `phase2b_research_v3`; collector: `phase2a_prospective_v4`; cohort: `prospective_v4`
- Recorder priority: HIGHER_THAN_OFFLINE_ANALYSIS - analysis never blocks the recorder.

## B. Test Baseline
- Pre-development `pytest` baseline recorded before any Phase 2B-Research code: **357 passed**.
- The baseline was re-run for real before development started (spec requirement); current count lives in `tests/`.

## C. Input Versions
- Closed SHA-verified raw files only: 9 files, sidecar/SHA failures: 0.
- Incremental manifest (v2/v3 version-separated caches): 3 cached / 0 parsed this run; spec `phase2b_research_v3`; timing semantics `phase2b_timing_semantics_v1`.

## D. Recorder Status
- Closed + SHA-verified raw only; active raw files are never formal inputs.
- Cohort observations: 0 eligible.

## E. Full Lifecycle Market Count
- **EXPLORATORY_SMALL_N** - full/partial 3/8, UTC days 1, BTC ticks 100703, valid/invalid PM states 666813/109042, shocks 667.

## F. Per-Market Lead-Lag
- Markets with estimates: 3; next B1 milestone: 10.
- direction tolerance |lag| <= 100ms => SYNCHRONOUS (frozen before results).

- `btc-updown-5m-1787590800` (2026-08-24): METHOD_A lag 250ms (r=0.3816) -> **BTC_LEAD**; METHOD_B 5000ms / METHOD_C 0ms -> METHOD_CONSISTENT_MARKET; shocks overlap/non-overlap 243/83; timing trust TIER_D, resolution BELOW_TIMING_RESOLUTION, coarse 0-500ms.
- `btc-updown-5m-1787594700` (2026-08-24): METHOD_A lag 250ms (r=0.6020) -> **BTC_LEAD**; METHOD_B 5000ms / METHOD_C 0ms -> METHOD_CONSISTENT_MARKET; shocks overlap/non-overlap 139/43; timing trust TIER_D, resolution BELOW_TIMING_RESOLUTION, coarse 0-500ms.
- `btc-updown-5m-1787595000` (2026-08-24): METHOD_A lag 250ms (r=0.4449) -> **BTC_LEAD**; METHOD_B 5000ms / METHOD_C 0ms -> METHOD_CONSISTENT_MARKET; shocks overlap/non-overlap 49/14; timing trust TIER_D, resolution NEAR_TIMING_RESOLUTION, coarse 0-500ms.

## G. Pooled vs Equal-Market-Weighted
- Shock-weighted pooled peak lag (diagnostic): 250ms (r=0.4330).
- Equal-market-weighted (primary stability evidence): mean lag 250.0000ms, median 250.0000ms, direction counts {'BTC_LEAD': 3}.
- Universal direction claim: True (requires >=3 markets and a single direction).
- Market-level bootstrap: NOT_COMPUTED_N_BELOW_10
- Cluster awareness: {'shock_count': 667, 'market_count': 3, 'day_count': 1} (shocks within a market are not independent).

## H. Overlap Dependence
- OVERLAPPING vs NON_OVERLAPPING_1S (refractory 1000ms, both retained): warnings 3/3.
- Pooled dependence: warning=True, sign_flip=False, max_rel_diff=0.5417.

## I. Exchange vs Receive Clock
- Per-market clock basis: {'CLOCK_BASIS_CONSISTENT': 3}; TIMING_RESOLUTION_WARNING on 3/3 markets.
- Latency drift is compared against the measured lag; same order of magnitude triggers a warning.
- v3 timing audit (registry, trust tiers, resolution statuses, agreement matrix): `D:\工作\量化\std0-quant\data\reports\phase2b_timing_audit_20260825T060535Z.json`.

## J. Latency Distributions
- BTC (exchange->receive): p50/p90/p95/p99/max = 2539.0000/2602.0000/2661.0000/2781.0000/3157.0000 ms.
- CLOB: p50/p90/p95/p99/max = 403.0000/9088.0000/9948.0000/10726.0000/11221.0000 ms.

## K. Shock Magnitude Stability
- 1-2bp: shocks 263 across 3 markets, signed 1s response 0.8137c, per-market sign +/- 3/0, sign_consistent=True.
- 2-5bp: shocks 137 across 3 markets, signed 1s response 0.3097c, per-market sign +/- 2/1, sign_consistent=False.
- 5-10bp: shocks 29 across 3 markets, signed 1s response 0.2679c, per-market sign +/- 2/1, sign_consistent=False.
- >10bp: shocks 2 across 1 markets, signed 1s response 0.7500c, per-market sign +/- 1/0, sign_consistent=True.

## L. Lifecycle Stability
- 0-60s: rows 723, shocks 131, markets 3, signed 1s response 0.6794c.
- 60-120s: rows 720, shocks 103, markets 3, signed 1s response -1.4320c.
- 120-180s: rows 720, shocks 140, markets 3, signed 1s response 0.5585c.
- 180-240s: rows 720, shocks 175, markets 3, signed 1s response -2.2747c.
- 240-300s: rows 717, shocks 118, markets 3, signed 1s response 0.0625c.

## M. Method Agreement
- METHOD_CONSISTENT_MARKET: 3/3; agreement remains exploratory.

## N. Response Magnitude (cents/share)
- 100ms: signed mean 0.3747c, abs median 0.0000c, p25/p75/p90 0.0000/0.0000/2.0000c, n=431.
- 250ms: signed mean 0.5244c, abs median 0.0000c, p25/p75/p90 0.0000/1.0000/2.0000c, n=430.
- 500ms: signed mean 0.6072c, abs median 0.0000c, p25/p75/p90 0.0000/1.0000/3.0000c, n=429.
- 1000ms: signed mean 0.6405c, abs median 1.0000c, p25/p75/p90 0.0000/1.5000/4.0000c, n=427.
- Latency-decay fractions (response_h / response_5s): {'100ms': 0.2676499834272456, '250ms': 0.37458471760797335, '500ms': 0.4337329337329336, '1000ms': 0.45751087320173967}.

## O. B1 Evidence Maturity
- **EARLY_REPLICATION** - 3 full-lifecycle markets; attained milestones [3]; next: 10.
- Goal: replicate the lead-lag *distribution*, not the single +250ms observation.

## P. B2 Observation Count
- **INSUFFICIENT_STD0_EVENTS** - 0 eligible fully-covered std0 observations; next milestone 1.

## Q. B2 N001
- Not available: no fully-covered prospective_v4 std0 observation yet (INSUFFICIENT_STD0_EVENTS).

## R. Phase 2A Status
- Confirmatory: ACCUMULATING_LIVE_DATA; frozen ledger/settings hash check: **PASS**; gates unchanged.

## S. Interpretation (v3.1) & Recorder Gate
- Direction: **DIRECTION_REPLICATED_EARLY**; lag magnitude: **LAG_MAGNITUDE_UNRESOLVED**.
- Across the 3 estimated eligible prospective_v4 markets, the dominant association is BTC_LEAD on all three clock views; however, the measured peak lags are below the current timing-resolution bound, so the lag magnitude is unresolved.
- Interpretation erratum: `D:\工作\量化\std0-quant\data\reports\phase2b_v3_interpretation_erratum_20260825T055232Z.json`.
- Recorder reliability gate: **MEMORY_HOTFIX_PASS** (engineering fix `recorder_reliability_fix_v1`; collector version unchanged); recorder state: **RECORDER_READY**.

## T. Limitations
- 3 formal full-lifecycle prospective_v4 markets are available; per-market tables grow as the recorder accumulates closed markets.
- PM source timestamps are per-frame server times (SOURCE_FRAME_TIME, FRAME_LEVEL); sub-second source-time lead-lag is descriptive only (TIMING_SEMANTICS_LIMITED).
- Local clock offset is UNKNOWN; receive-minus-source mixes transport with clock offset and is never decomposed into the two.
- Minimum resolvable lag (frozen heuristic) is 10323.0000 ms - materially larger than any observed sub-second peak; sub-second lag magnitudes are BELOW/NEAR timing resolution.
- Receive-time burst quantization (shared asyncio loop) limits ordering inside identical-ms bursts.
- Overlapping shock anchors are descriptive and not independent observations; NON_OVERLAPPING_1S is retained alongside them; effective evidence scales with market count, not shock count.
- METHOD_B peak horizon measures response magnitude timing, not onset; agreement is descriptive only.
- B2 std0 timestamps are second-level; B2 can never validate a 250ms reaction (>=1s ambiguity by construction).
- No causal, alpha, profitability, execution or trading conclusion is authorized.

## U. Decision
- **EXPLORATORY_PIPELINE_READY + EXPLORATORY_EVIDENCE_ACCUMULATING + EARLY_REPLICATION + INSUFFICIENT_STD0_EVENTS**

No causal, alpha, profitability, execution or trading conclusion is authorized. 'REPLICATE BEFORE EXPLAIN'.
