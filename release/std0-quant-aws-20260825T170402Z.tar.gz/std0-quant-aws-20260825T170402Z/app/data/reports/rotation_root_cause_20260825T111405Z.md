# Rotation Root-Cause Audit

## Decision

`ROTATION_CLASSIFIER_FALSE_POSITIVE` + `BOOK_NETWORK_GAPS_CONFIRMED`

For market `btc-updown-5m-1787653500`, discovery, subscription, and dual-token valid state all occurred before market start. The endpoint rotation predicate receives:

- discovery: 54.391 seconds before start;
- subscription: 8.996 seconds before start;
- dual-token valid state: 8.577 seconds before start;
- rotation gap: 0;
- mid-market CLOB reconnects: 0.

Its correct result is no rotation failure. The old acceptance artifact manually mapped invalid BTC coverage evidence to `ROTATION_COVERAGE_FAILURE`; no repository rotation predicate produced that result. The expected state was coverage evidence pending, not rotation failure.

## Real Book gap in market 1787653500

There was a real 5.827-second Book processing gap on the same socket and connection ID. Book state was valid before and after it, with no reconnect or snapshot reinitialization. The gap ended within 2 ms of next-market Gamma discovery.

Root cause: synchronous Gamma HTTP discovery ran inside the async Book orchestration loop and temporarily blocked frame processing. This is a real rotation-related operational gap, but it is mid-market and did not fail the frozen coverage gate: 298/300 = 99.3333%.

## Four CLOB reconnects

| Market | Reason | Detection→schedule | Backoff | Handshake | Subscribe→dual-ready | Raw downtime |
|---|---|---:|---:|---:|---:|---:|
| 1787652900 | REMOTE_CLOSE | 1 ms | 1.041 s | 5.991 s | 0.386 s | 7.421 s |
| 1787652900 | slow-consumer REMOTE_CLOSE | 1 ms | 2.230 s | 6.238 s | 0.417 s | 8.887 s |
| 1787652900 | WATCHDOG_STALE | 1 ms after disconnect | 1.036 s | 6.769 s | 0.416 s | 8.225 s |
| 1787653200 | PING_TIMEOUT | 2 ms | 1.062 s | 6.007 s | 0.352 s | 17.510 s total |

The 17.510-second PING_TIMEOUT gap includes about 10.087 seconds between the last valid message and error detection; configured backoff was not the dominant component. No backoff or reconnect policy was changed.

Eligibility policy remains `prospective_v4_eligibility_v2`: the policy already separates endpoint rotation from independent mid-market coverage, so no v3 policy is warranted.
