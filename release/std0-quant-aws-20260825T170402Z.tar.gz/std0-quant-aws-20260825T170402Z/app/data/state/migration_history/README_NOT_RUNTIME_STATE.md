# Historical migration snapshots

Files in this directory are provenance only and MUST NOT be interpreted as active AWS runtime, PID, session, or O3 state.
