# std0-quant — Phase 1: data infrastructure

Auditable behavioral reconstruction of Polymarket trader **std0**
(wallet `0xdf7930e89a2c47560165331863c31deca0733dcd`) on **Bitcoin Up or
Down 5-minute** markets.

**THIS PROJECT DOES NOT PLACE REAL TRADES IN PHASE 1.** It is data
collection + event labeling only: no executor, no order signing, no private
keys are ever requested, stored, or processed.

---

## 1. Purpose

Phase 1 builds a fully reproducible, append-only data pipeline that turns
std0's public fills into a per-market **event ledger** (initial direction,
FirstOpposite, Y30 label) with strict reconciliation and zero silent drops.
No models, no trading (that is explicitly deferred; see "Next steps").

## 2. Frozen research definitions

These are validated at config load time (`config.py::_validate_frozen`):
editing them in `config/settings.yaml` makes the program refuse to start.

| Definition | Value | Meaning |
|---|---|---|
| Episode rule | `v1_3sec` | same market + same direction BUY fills chain into one parent episode while consecutive fills are ≤ 3000 ms apart (gap > 3000 ms splits); the window is inclusive (exactly 3000 ms merges) |
| Y30 horizon | `30 s` | window `(t0, t0+30s]` with `t0 = first_opp_end` (episode **end** timestamp) |

* **Raw Fill** — append-only record of every std0 fill, stored verbatim
  (see schema below). Never overwritten, never deleted.
* **Parent Episode** — BUY-only chaining under the 3 s rule; keeps its
  constituent fill ids and tx hashes; `vwap = Σp·s / Σs`.
* **Initial Direction** — the outcome of std0's earliest BUY. If the first
  Up BUY and the first Down BUY share the same second, the market is
  excluded with `SAME_SECOND_DIRECTION_AMBIGUITY` — never guessed.
* **FirstOpposite** — the first BUY parent episode of the direction
  opposite to the initial one. Interpretation (inventory rebalance /
  hedge / liquidity) is deliberately NOT assumed to be alpha.
* **Y30** — 1 if std0 BUYs the FirstOpposite direction in `(t0, t0+30s]`;
  a BUY at exactly `t0` does not count (it would have merged into the
  episode under the 3 s rule), a BUY at exactly `t0+30s` does. If the
  market ended before `t0+30s`, the market stays clean with
  `y30_horizon_eligible = false` (censored, **not** a plain negative).

## 3. Data sources (all public)

| Source | Endpoint | Use |
|---|---|---|
| Polymarket data API | `GET https://data-api.polymarket.com/trades?user=<wallet>` | std0's fill history (takerOnly=false, offset paging, `start`/`end` epoch-second filters) |
| Polymarket Gamma API | `GET https://gamma-api.polymarket.com/markets?slug=<slug>` | live-market discovery + token ids for book recording |
| Polymarket CLOB WS | `wss://ws-subscriptions-clob.polymarket.com/ws/market` | realtime order book (`{"assets_ids": [...], "type": "market"}`; app-level `PING`→`PONG`) |
| Binance WS | `wss://stream.binance.com:9443/ws/btcusdt@trade` | BTC/USDT trade ticks |

## 4. Install

```bash
cd std0-quant
python -m venv .venv && .venv\Scripts\activate     # Windows
pip install -e ".[dev]"                            # or: pip install -e .
pytest                                             # 330 tests
```

Python 3.12. Runtime deps: `requests`, `websockets`, `pydantic`,
`PyYAML`, `python-dotenv`, `pyarrow`, `duckdb`.

## 5. Commands

```bash
# 1) sync std0's fills (incremental; idempotent)
python scripts/sync_std0_trades.py

# deep-history backfill: slices (start, end] windows past the API's
# 10000-offset cap by shrinking end to earliest-seen minus 1s
python scripts/sync_std0_trades.py --backfill --start 2026-03-01

# 2) build normalized fills + parent episodes (rule v1_3sec)
python scripts/build_episodes.py

# 3) build the per-market event ledger + reconciliation + coverage reports
python scripts/build_event_ledger.py

# 4) live collection: BTC book (market channel, auto market rotation)
#    + Binance BTC ticks; append-only raw + session journals
python scripts/collect_live.py --duration-minutes 60

# synthetic end-to-end fixture (no network): 12 markets covering every
# exclusion path; validates sync→episodes→ledger→reconciliation
python scripts/dev_seed_fixture.py
```

Optional env overrides: `STD0_WALLET`, `POLYMARKET_DATA_API`,
`POLYMARKET_GAMMA_API`, `POLYMARKET_WS_URL`, `BTC_WS_URL`.

## 6. Timestamp convention

* All internal timestamps are **epoch milliseconds, UTC**.
* The data API returns `timestamp` as epoch **seconds** with second
  granularity → converted `×1000` on ingest. Sub-second fill ordering
  within one second is not publicly observable (known limitation).
* Every raw record keeps `timestamp_raw` (untouched API value); every
  realtime row stores both `receive_timestamp_ms` (local clock) and
  `exchange_timestamp_ms` (exchange clock when provided).
* Market windows come from the slug: `btc-updown-5m-<unix_start_s>` →
  `[ts, ts+300s)` (verified: slug ts always 5-minute aligned; gamma
  `endDate == slug_ts+300s` for live markets).

## 7. Schemas

### Raw fill record (data API, observed live)

```json
{
  "proxyWallet": "0xdf79...", "side": "BUY", "asset": "<clob token id>",
  "conditionId": "0x...", "size": "100", "price": "0.55",
  "timestamp": "1787480700", "title": "Bitcoin Up or Down - Aug 22, ...",
  "slug": "btc-updown-5m-1787480700", "outcome": "Up", "outcomeIndex": 0,
  "transactionHash": "0x...", "name": "std0", "pseudonym": "std0"
}
```

No unique `id` field exists → fill identity =
`sha256(transactionHash|asset|side|size|price|timestamp|outcomeIndex)`
(prefixed `ck:`). Raw store: one NDJSON line per fill
`{source, sync_run_id, fetched_at_ms, record}` under
`data/raw/std0_trades/`; verbatim page bodies under `data/raw/api_pages/<run_id>/`.

### Event ledger (`data/derived/event_ledger.parquet`, one row per market)

`market_id, condition_id, slug, market_start_ms, market_end_ms,
initial_direction, initial_first_timestamp_ms, initial_qty,
first_opp_direction, first_opp_start_ms, first_opp_end_ms,
first_opp_qty, first_opp_vwap, first_opp_fill_count,
up_qty_before_first_opp, down_qty_before_first_opp, old_direction_qty,
y30, y30_horizon_eligible, y30_event_ts_ms,
clean_flag, exclude_reason, exclude_detail,
poly_book_coverage_pct, btc_coverage_pct,
episode_rule_version, n_buy_fills, n_sell_fills`

### Book row (per WS message, `data/raw/polymarket_book/book_*.ndjson`)

`receive_timestamp_ms, exchange_timestamp_ms, condition_id, token_id,
outcome, best_bid, best_ask, mid, spread, bids[], asks[],
last_trade_price/size/side, event_type, raw_message`

### BTC tick row (`data/raw/btc_ticks/btc_*.ndjson`)

`receive_timestamp_ms, exchange_timestamp_ms (T), event_timestamp_ms (E),
price, size, trade_id, buyer_is_maker, raw_message`

## 8. Exclusion rules (no silent drops — ever)

Every market std0 traded produces exactly one ledger row. A market is
either `clean_flag=true` or carries exactly one `exclude_reason`:

| Reason | Trigger |
|---|---|
| `FIELD_INCOMPLETE` | no BUY fills; or BUY fills with invalid size/price/fields; or >2 outcomes |
| `SAME_SECOND_DIRECTION_AMBIGUITY` | first Up BUY and first Down BUY share a timestamp |
| `MARKET_METADATA_MISSING` | slug does not encode a usable 5m window (and no metadata) |
| `BOOK_DATA_MISSING` / `BTC_DATA_MISSING` | a recording session promised coverage but the data is absent |
| `TIMESTAMP_INVALID` | unparseable fill timestamp |
| `OTHER` | anything else (e.g. `out_of_scope_market` for non-BTC-5m series; trades/metadata time inconsistencies). **detail is mandatory** |

Reconciliation (`data/reports/reconciliation_<stamp>.{json,md}`) enforces:
raw markets == clean + excluded; reason counts sum == excluded; every
OTHER row has detail; y30 positives + negatives + censored == markets
with FirstOpposite.

Note: std0 also trades `btc-updown-15m`, `eth-updown-*`, `sol-updown-*`,
`xrp-updown-*` series. They are **kept** in the raw store and the ledger
(excluded `OTHER/out_of_scope_market`) so reconciliation balances over
everything raw contains — nothing is dropped, the study universe is just
labeled.

## 9. API behaviors verified live (2026-08-23)

* `data-api /trades`: offset paging **hard-capped at 10000** beyond which
  the API returns `400 {"error":"max historical trades offset of 10000
  exceeded"}`; `limit=500` works; results are newest-first; **`start`/`end`
  (epoch seconds) do filter** (the syncer verifies this on every run and
  aborts with `time_params_not_honored` if the API ever stops honoring them).
* `takerOnly=false` is sent explicitly (config `polymarket.sync.taker_only`).
* Gamma `/markets?slug=...` finds **active** markets but returns empty for
  **closed** ones (also with `closed=true`/`archived=true`, and
  `condition_ids` lookups); historical windows are therefore derived from
  slugs, which is deterministic and offline.
* Gamma `startDate` is the market **creation** time, NOT the 5m window
  start; `endDate` is the window end. CLOB `/markets/<conditionId>` still
  serves closed markets (tokens/outcomes) when needed.
* CLOB market WS sends `book` snapshots (with `buy_levels`/`sell_levels`),
  `price_change`, `last_trade_price`, `tick_size_change`; keepalive is
  app-level text `PING` → reply `PONG`.

## 10. Known limitations

1. **Second-granularity timestamps**: the data API only provides epoch
   seconds. Fill ordering inside one second is unobservable; episode
   chaining inside a same-second burst is order-insensitive by design
   (all fills of one second merge into the same episode), but two truly
   distinct bursts in the same second cannot be told apart.
2. **Identical-fill dedupe**: two genuinely distinct fills that agree on
   `transactionHash|asset|side|size|price|timestamp|outcomeIndex` collapse
   to one identity. The sync counts these (`within_page_identity_collisions`,
   553 in the current full backfill) instead of guessing. API page replays
   across pages are normal duplicates and deduplicate exactly.
3. **No historical order book**: the CLOB WS only serves live data; book
   coverage exists solely for windows recorded by `collect_live.py`
   (Phase 1 records going forward).
4. **Y30 uses fill timestamps**, not exchange matching-engine sequencing;
   boundary cases at exactly `t0`/`t0+30s` follow the frozen window
   semantics and are unit-tested.
5. **Gamma closed-market gap** (see §9): windows rely on slug derivation;
   a malformed slug yields `MARKET_METADATA_MISSING` rather than a guess.

## 11. Testing

```bash
pytest                  # 357 tests, ~5 s, no network required
```

Covers the spec's Tests A–H: dedupe/idempotency (A), same-second
same-outcome fills coexisting (B), ambiguity exclusion (C), VWAP formula
(D), Y30 window boundaries (E), horizon censoring (F), future-leakage
assertion utility (G, `audit/leakage.py`), reconciliation invariants (H) -
plus offset-cap/backfill behavior, slug window derivation, scope
filtering, WS reconnect/resubscribe, coverage/gap analysis.

Phase 1.5 adds Tests I–O: selection-bias SMD/grouping (I), BUY-only
sensitivity boundaries (J), collision scan/A-B comparison (K), temporal
bucketing/stability rule (L), universe placebo summaries (M), negative
controls incl. the leakage-detection FAIL case (N), point-in-time cutoff
semantics (O).

`scripts/dev_seed_fixture.py` builds an isolated `data_fixture/`
workspace and runs the *real* pipeline over 12 synthetic markets
(clean / censored / each exclusion reason / boundary cases), asserting
strict reconciliation.

## 12. Phase 1.5 - Bias & Robustness Audit

```bash
python scripts/run_bias_audit.py [--ledger PATH] [--output DIR]
                                  [--n-shuffles N] [--seed N]
                                  [--min-weekly-n N]
```

Read-only audit of the frozen Phase 1 truth: hashes
`event_ledger.parquet` (file bytes + semantic content over
`condition_id|clean_flag|exclude_reason|y30|y30_horizon_eligible`) and
`config/settings.yaml` before and after, and FAILS if either changed.
Outputs `data/reports/bias_audit_<stamp>.{json,md}` plus a per-market
audit-only-label CSV under `data/derived/audit/`.

The six audits (modules under `src/std0_quant/audit/`):

| # | module | question |
|---|---|---|
| 1 | `selection_bias.py` | do clean markets with/without a FirstOpposite differ on pre-FirstOpposite variables (SMD; WARN at >=2 material) |
| 2 | `buy_only_sensitivity.py` | how much does the BUY-only y30 event definition matter (audit-only directional label, never replaces y30) |
| 3 | `collision_sensitivity.py` | do within-page trade-identity collisions move headline rates (dataset A vs B; LOW_SENSITIVITY at <1pp) |
| 4 | `temporal_stability.py` | are rates stable across ISO weeks (WARN at >=10pp spread or jump; low-N weeks kept, flagged, excluded from the rule) |
| 5 | `universe_placebo.py` | do the patterns replicate under the same construction on BTC-15m/ETH-5m/SOL-5m/XRP-5m (NOT_COMPARABLE when data is too thin) |
| 6 | `negative_controls.py` | within-ISO-week label shuffle + logistic regression: AUC p95 > 0.55 FAILs (leakage / calendar-structure red flag); future-window placebo labels; global-shuffle diagnostic |

All thresholds are descriptive, not significance tests. No causal
claims. The audit never modifies labels, episodes, raw pages, or
settings, and never sends anything anywhere.

## 13. Repository layout

## Phase 1.6 — Regime & Conditional Predictability Audit

```bash
python scripts/run_regime_audit.py --n-shuffles 1000
```

This offline, read-only audit separates calendar/regime base-rate effects
from episode-level conditional information. It produces daily/weekly
Wilson surfaces, descriptive change points, past-only online regimes,
regime probability baselines, conditional negative controls, expanding-
window logistic evaluation, feature drift, calendar-matched placebos and
future-window persistence. Descriptive full-sample regimes are never model
features. The Phase 1 ledger, settings and semantic truth are hashed before
and after every run. This remains research/audit only: no real trading and
no profitability or causal inference.

## 14. Repository layout

## Phase 2A — Point-in-Time Public State & Feature Attribution

```bash
python scripts/build_pretrade_features.py --cutoff cutoff_1
python scripts/run_phase2a.py
```

Phase 2A joins frozen FirstOpposite observations to locally recorded
Binance ticks and Polymarket CLOB rows only. Public events must precede the
selected cutoff (`t0-1s` for the primary analysis); every feature carries
source timestamps and missing reasons. The default modeling gate requires
99% BTC pre-30s and book pre-10s coverage, at least 5,000 observations and
14 calendar days. Missing live history is never downloaded, backfilled or
imputed past the gate. This remains behavioral research only and contains
no PnL, execution, sizing, or real-trading code.

## Phase 2A-Live — Recorder Engineering

The append-only public-data recorder rotates raw NDJSON hourly or by size,
writes SHA256 sidecars when files close, and journals connections, gaps,
staleness, queue backpressure and process exits. Stopping it creates permanent
historical book gaps. This component never trades.

## Phase 2A-Prospective — Prospective Cohort

### Current primary version

`prospective_v4` is frozen as the only primary cohort version. Its immutable
start is market `btc-updown-5m-1787590800` at `1787590800000` ms UTC, with
freeze reason `ENGINEERING_VALIDATION_COMPLETE`. Earlier versions and their
raw files, sidecars, manifests and reports remain preserved, but are
`primary_model_eligible = false` unless a future independent cross-version
equivalence audit is authorized.

### Prospective Recorder Version History

#### prospective_v1

Initial prospective recorder implementation.

#### prospective_v2 — ENGINEERING_FIX

- Correctly expands CLOB `price_changes[]` batched token updates.
- Requires valid dual-token snapshot state and retains the configured
  five-second stale bound.

#### prospective_v3 — ENGINEERING_FIX

- Stores each parent websocket batch once by frame reference.
- Fixes gap-journal field mapping while preserving v1/v2 artifacts.

#### prospective_v4 — ENGINEERING_FIX

- Persists bounded top-of-book derived state; immutable raw websocket frames
  remain the raw truth.
- Uses a bounded zero-drop worker queue and keeps coverage scans off the
  websocket receive loop.
- Retains the gap-journal fix, dual-token validity and five-second stale
  semantics. No label, feature, cutoff or research threshold was tuned.

### Current state and gates

Current engineering state is `PROSPECTIVE_PIPELINE_READY` and operational
state is `ACCUMULATING_LIVE_DATA`.

- O1 — first v4 full-lifecycle market: PASS (BTC 0.996667, book 1.000000).
- O2 — first fully-covered v4 std0 observation plus lineage: pending until a
  naturally eligible FirstOpposite/Y30 observation occurs.
- O3 — a true continuous 24-hour supervisor session: pending. Fragmented
  smoke sessions are never stitched into a 24-hour PASS.
- C100/C500/C1000 — coverage/provenance, distribution/sanity and drift/schema
  audits respectively; none fits a formal model.
- FINAL — at least 5,000 fully-covered observations on at least 14 covered UTC
  days, with zero PIT violations and no unresolved major integrity/provenance
  failures. This permits Phase 2A revalidation only; it never authorizes
  Phase 2B-Confirmed. Exploratory Phase 2B research is governed separately.

### Run

```powershell
# freeze/check status
python scripts/live_status.py

# long-running prospective collector
python scripts/run_live_supervisor.py

# daily/operations audit
python scripts/report_live_coverage.py

# milestone audit
python scripts/run_prospective_checkpoint.py

# readiness only; starts no model or later phase
python scripts/check_phase2a_readiness.py
```

After the FINAL gate only:

```powershell
python scripts/build_pretrade_features.py --cutoff cutoff_1
python scripts/run_phase2a.py
```

The versioned index is `data/state/prospective_cohort.json`; deterministic
observation identities prevent rebuilds from inflating the sample. Historical
baseline snapshots allow new conditions but hard-fail if frozen rows change.
Daily reports are `prospective_daily_YYYYMMDD.{json,md}`. Operations artifacts
explicitly report the longest true continuous session and distinguish market
window events from post-market shutdown events.

```
config/settings.yaml          # runtime config (frozen defs validated)
src/std0_quant/
  config.py  timeutil.py  storage.py  logging_setup.py
  collectors/  std0_trades.py  polymarket_book.py  btc_ticks.py  ws_runner.py
  events/      fills.py  episode_builder.py  first_opposite.py  event_ledger.py
  audit/       leakage.py  coverage.py  reconciliation.py
               point_in_time.py  selection_bias.py  buy_only_sensitivity.py
               collision_sensitivity.py  temporal_stability.py
               universe_placebo.py  negative_controls.py  bias_report.py
scripts/  sync_std0_trades.py  build_episodes.py  build_event_ledger.py
          collect_live.py  dev_seed_fixture.py  run_bias_audit.py
tests/    330 unit/integration tests (no network)
data/     raw (append-only) / normalized / derived / reports / state / sessions
```

## Phase 2B-Research — Exploratory Microstructure

Governance is split explicitly:

- Phase 2B-Research: `AUTHORIZED_EXPLORATORY`
- Phase 2B-Confirmed: `NOT_AUTHORIZED`
- Strategy research: `NOT_AUTHORIZED`
- PnL / execution / trading: `NOT_AUTHORIZED`

Track B runs offline and never on the websocket receive loop. B1 uses only
closed, SHA-verified `phase2a_prospective_v4` files and studies descriptive
BTC↔Polymarket lead-lag associations on versioned 100/250/500/1000ms grids.
B2 automatically becomes available after the first fully-covered v4 std0
observation, while applying conservative second-granularity timestamp rules.
It does not lower or modify any Phase 2A gate, label, feature, cutoff or M0–M4
specification.

```powershell
python scripts/run_phase2b_research.py
python scripts/build_phase2b_audit_notebook.py
```

Outputs are under `data/derived/phase2b/`, `data/reports/phase2b_*.{json,md}`
and `notebooks/phase2b_exploratory_data_quality.ipynb`. Evidence labels such
as `TINY_SAMPLE` describe maturity only; they are not significance, causal,
alpha, profitability or executability claims.

### Per-market lead-lag stability audit (research spec `phase2b_research_v2`)

`research/phase2b_stability.py` extends the bootstrap with the evidence
accumulation layer. Every run is versioned and immutable and reuses unchanged
raw files through a processed-file SHA manifest
(`data/state/phase2b_research_state.json` + timeline cache under
`data/derived/phase2b/cache/`), so the recorder keeps running while analysis
catches up incrementally. Frozen before any result: direction tolerance
(|lag| ≤ 100ms ⇒ SYNCHRONOUS), 1000ms refractory, ±2000ms lag grid,
METHOD_C lag grid, response horizons, economic horizons (100/250/500/1000ms
in cents/share), shock/lifecycle buckets, bootstrap settings
(market-level, N ≥ 10, seed 20260824) and dependence thresholds.

- **Per-market lead-lag table** (`per_market_lead_lag_<run_id>.parquet`):
  one row per FULL_LIFECYCLE `prospective_v4` market with METHOD_A
  (cross-correlation), METHOD_B (shock response), METHOD_C (lagged OLS),
  direction, ≥2/3 method agreement, OVERLAPPING and NON_OVERLAPPING_1S shock
  counts, exchange/receive clock-basis comparison, latency percentiles and
  response magnitudes. Pooled (shock-weighted) is reported only as a
  diagnostic; equal-market-weighted is the primary stability evidence.
- **Honest warnings, never hidden**: `DEPENDENCE_SENSITIVITY_WARNING` when
  overlapping and non-overlapping responses disagree; `TIMING_RESOLUTION_WARNING`
  when latency drift is the same order as the measured lag;
  `CLOCK_BASIS_INSTABILITY` when the two clock bases disagree.
- **B1 milestones** M3/M10/M20/M50/M100 with states TINY_SAMPLE →
  BROAD_EXPLORATORY_EVIDENCE; first attainment writes an immutable
  `phase2b_b1_m<N>_<run_id>.{json,md}` report (idempotent).
- **B2 milestones** N001…N500 activate automatically at the first
  fully-covered v4 std0 observation (`observation_id` from the Phase 2A
  prospective cohort is the primary key; post-fill anchor is
  `fill_second_end`; same-second millisecond ordering is forbidden).
- Decision vocabulary is pre-registered and asserted; `ALPHA_PROVEN` /
  `STRATEGY_PROVEN` / `READY_TO_TRADE` can never appear.

Current data state (2026-08-24): 1 full-lifecycle market, 4 partial, 1 UTC
day. The single market classifies BTC_LEAD at +250ms (r=0.38), but
`TIMING_RESOLUTION_WARNING` (CLOB latency drift ≈ 5.8s ≫ 250ms) and
`DEPENDENCE_SENSITIVITY_WARNING` (overlapping vs non-overlapping responses
differ by 81%) both fire. B1 = TINY_SAMPLE, B2 = INSUFFICIENT_STD0_EVENTS;
next milestones are 3 full markets, then 10, then the first std0 observation.
Goal: replicate the lead-lag *distribution* - "REPLICATE BEFORE EXPLAIN".
Pre-development pytest baseline: 330 passed (current count in `tests/`).

### Timing integrity & cross-market replication audit (research spec `phase2b_research_v3`)

`research/phase2b_timing.py` audits **what the timestamps mean before any
lead-lag number is interpreted** ("MEASURE THE CLOCK BEFORE MEASURING THE
LAG"). Proven from collector code and raw payloads and frozen in
`data/state/timing_semantics_registry.json` (7 fields, frozen before viewing
any new-market aggregate):

- BTC `exchange_timestamp_ms` = Binance trade time T = SOURCE_EVENT_TIME
  (HIGH trust, event-level); PM `exchange_timestamp_ms` = CLOB per-frame
  server timestamp = SOURCE_FRAME_TIME (MEDIUM, FRAME_LEVEL - batched
  `price_changes[]` children inherit the parent frame timestamp; proven NOT
  last-trade time). Both `receive_timestamp_ms` = LOCAL_RECEIVE_TIME on one
  local clock (BTC burst-quantized by the shared asyncio loop); local clock
  offset is UNKNOWN and never retroactively corrected. std0 fills are
  SECOND_LEVEL (same-second ms ordering forbidden).
- Per-event latency decomposition keeps `receive - frame_ts`
  (FRAME_DELIVERY_DELAY, never claimed as event network latency) strictly
  separate from STATE_AGE, and adds three clock views per market: VIEW_A
  source timestamps (descriptive only), VIEW_B local receive timestamps
  (primary valid view), VIEW_C state-availability timestamps (no-backdating
  hard check; equals VIEW_B numerically for this synchronous collector -
  asserted, not assumed).
- Frozen heuristics (do not retune): minimum resolvable lag =
  max(p99-p50 of BTC, p99-p50 of CLOB receive-minus-source); trust tiers
  A>=4x / B>=2x / C>=1x / D<1x of that bound (never upgraded for direction
  consistency); ABOVE/NEAR/BELOW_TIMING_RESOLUTION; coarse buckets
  0-500/500-1000ms/1-2s/>2s.
- Runner outputs `phase2b_timing_audit_<run_id>.{json,md}` (sections A-T),
  `timing_diagnostics_<run_id>.parquet` and
  `per_market_lead_lag_v3_<run_id>.parquet`; v2 and v3 caches are
  SHA/spec/timing-semantics keyed and can never collide (same raw SHA set +
  spec + timing semantics + seed -> byte-identical per-market outputs;
  regression-tested and double-run verified on the real 3-market data).

Real-data result (run `20260824T193505Z`, 3 full-lifecycle v4 markets,
100,703 BTC ticks, 666,813 PM states, 667 shocks, 1 UTC day): all three
markets classify BTC_LEAD on **all three clock views** (VIEW_A 250ms,
VIEW_B/C 500ms; METHOD_CONSISTENT_MARKET 3/3), so the direction replicates
3/3 (`raw_btc_lead_fraction = 1.0`). But the frozen minimum-resolvable-lag
bound is **10,323 ms** (BTC receive-minus-T p50 2539ms with CONSTANT_OFFSET
pattern in the first market vs ~170ms later; CLOB frame delivery p50 403ms /
p99 10,726ms), so every sub-second peak is BELOW/NEAR_TIMING_RESOLUTION
(`timing_resolved_btc_lead_fraction = 0.0`, all markets TIER_D).
v2 +250ms reassessment: **DIRECTIONALLY_ROBUST_BUT_LAG_UNRESOLVED** - the
direction stands, the magnitude does not; `CONFIRMED_250MS` is not in the
vocabulary. B1-M3 milestone written automatically at the 3-market gate
(`EARLY_REPLICATION`); B2 = INSUFFICIENT_STD0_EVENTS (0 eligible std0
observations). Timing decision: TIMING_SEMANTICS_LIMITED +
TIMING_RESOLUTION_INSUFFICIENT, confidence LOW. 667 shocks are clustered in
3 markets on 1 day (effective evidence = market count); DEPENDENCE warnings
fire on 3/3 markets. Honest summary (corrected by
`phase2b_v3_interpretation_erratum_20260825T055232Z`): "Across the first
three eligible prospective_v4 markets, all three clock views classify the
dominant association as BTC_LEAD; however, the measured positive lags are
below the current timing-resolution bound, so the lag magnitude is
unresolved." - DIRECTION_REPLICATED_EARLY + LAG_MAGNITUDE_UNRESOLVED.
Pre-development pytest baseline: 357 passed (current count in `tests/`).

#### Recorder reliability gate (v3.1, engineering-only)

`collectors/recorder_reliability.py` detects and records the recorder
memory/fault-isolation hotfix state: low-allocation streaming SHA-256
(preallocated readinto buffer), bounded health tail reader (no big-block
`read().splitlines()`), HEALTH_REPORT_FAILURE isolation that can never kill
the raw collectors, close-task exception ownership (no "Task exception was
never retrieved"), RAW_WRITE_FAILURE / SIDECAR_FINALIZATION_FAILURE /
HEALTH_REPORT_FAILURE classification, grace-filtered orphan-sidecar startup
recovery, and RSS + queue telemetry. Current state: MEMORY_HOTFIX_PASS with
engineering_fix_version `recorder_reliability_fix_v1`; because no raw
event/parser/book/timestamp/coverage semantics changed, the collector
version stays `phase2a_prospective_v4` (no v5 bump).

#### Recorder network stability (`network_stability_fix_v1`, engineering-only)

Network/proxy failures are contained without changing the configured route:
Gamma discovery retries through the prediscovery window, websocket errors
retain exponential reconnect backoff, full `collect_live` crash loops gain
supervisor backoff plus `RESTART_STORM_WARNING`, and proxy dependency state is
exposed in live health. Closed-market coverage scans run in a below-normal
separate process so Python JSON decoding cannot starve websocket frame
handling or the local-receive-time watchdog. Lifecycle classification uses
recorder readiness at both market endpoints; reconnect gaps remain governed
independently by the unchanged 99% BTC/book coverage gate. Raw schema,
parsing, timestamps, book reconstruction, cohort version and all research
definitions remain `prospective_v4` / frozen.

```powershell
python scripts/audit_recorder_network.py --session-id <closed-supervisor-session>
```

#### v3.1 interpretation hierarchy in every report (L1/L2/L3)

Per-market lead-lag rows now carry the strict three-level interpretation:
Level 1 direction (BTC_LEAD / PM_LEAD / SYNCHRONOUS / UNKNOWN), Level 2
coarse magnitude interpretable ONLY when |peak| >= the timing-resolution
bound (otherwise `UNRESOLVED`), Level 3 exact grid peak always descriptive
(`DESCRIPTIVE_ONLY` while below the bound). The runner's
`interpretation_guard` rejects any supported conclusion that contains a
magnitude claim ("leads by 250ms", "within 500ms", "0-2s", any `NNNms`)
while the peak is below the bound, and the timing audit gains a
"U. Interpretation (v3.1 hierarchy)" section plus the recorder-gate line.
M-milestone payloads carry the full evidence-accumulation field set (n_days,
direction fractions, VIEW/METHOD agreement, per-market bounds + median,
market-level bootstrap with unit=MARKET, timing-resolved fraction always
separate from the raw lead fraction). Verification run `20260825T060535Z`:
3/3 cache hits, frozen PASS, guard accepts the corrected conclusion
(DIRECTION_REPLICATED_EARLY + LAG_MAGNITUDE_UNRESOLVED), M3 artifact not
rewritten. Tests: PC1-PC10 in `tests/test_phase2b_v31.py` (398 passed
total). The live supervisor was restarted after the gate PASS and is
accumulating live data again (O3 clock restarted from zero).
